({
	doInit : function(component, event, helper) {
		//component.get("v.recordslist");
        //alert('RecordsList is-->'+JSON.stringy(component.get("v.recordslist")));
	}
})