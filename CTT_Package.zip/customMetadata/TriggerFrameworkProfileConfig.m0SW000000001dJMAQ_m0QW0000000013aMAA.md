<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>m0SW000000001dJMAQ_m0QW0000000013aMAA</label>
    <protected>false</protected>
    <values>
        <field>Config__c</field>
        <value xsi:type="xsd:string">ExposedContactBeforeInsertHelper</value>
    </values>
    <values>
        <field>Disabled__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Function_Name__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Profile__c</field>
        <value xsi:type="xsd:string">Resource_Coordinator</value>
    </values>
</CustomMetadata>
